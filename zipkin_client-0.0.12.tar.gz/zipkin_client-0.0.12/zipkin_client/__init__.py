from py_zipkin.util import generate_random_64bit_string
from py_zipkin.zipkin import create_http_headers_for_new_span
from py_zipkin.zipkin import create_attrs_for_span
from py_zipkin.zipkin import ZipkinAttrs
from py_zipkin.zipkin import zipkin_span
import requests

TRACE_HEADERS_TO_PROPAGATE = ['X-Ot-Span-Context','X-Request-Id','X-B3-TraceId','X-B3-SpanId','X-B3-ParentSpanId','X-B3-Sampled','X-B3-Flags','X-Forwarded-Proto','Host']

def http_transport(encoded_span):
    requests.post('http://zipkin:9411/api/v1/spans', data=encoded_span, headers={'Content-Type': 'application/x-thrift'},)

def extract_zipkin_attrs(headers):
    return ZipkinAttrs(headers['X-B3-TraceId'], generate_random_64bit_string(), headers['X-B3-SpanId'], headers.get('X-B3-Flags', ''), headers['X-B3-Sampled'],)


def connect(service_name=None, span_name=None, request=None):
    headers = {}
    if request is None:
        headers.update(create_http_headers_for_new_span())
        return zipkin_span(service_name=service_name, span_name=span_name, transport_handler=http_transport,
                           zipkin_attrs=create_attrs_for_span())
    for header in TRACE_HEADERS_TO_PROPAGATE:
        if header in request.headers:
            headers[header] = request.headers[header]
    if not headers:
        return zipkin_span(service_name=service_name, span_name=span_name, transport_handler=http_transport,
                           zipkin_attrs=create_attrs_for_span())
    if 'X-B3-TraceId' not in headers or 'X-B3-SpanId' not in headers:
        return zipkin_span(service_name=service_name, span_name=span_name, transport_handler=http_transport,
                           zipkin_attrs=create_attrs_for_span())
    return zipkin_span(service_name=service_name, span_name=span_name, transport_handler=http_transport,
                zipkin_attrs=extract_zipkin_attrs(headers))

def get_headers(request):
    result = {}
    if request is None:
        return result
    for header in TRACE_HEADERS_TO_PROPAGATE:
        if header in request.headers:
            result[header] = request.headers[header]
    return result

def create_headers(request):
    headers = request.headers
    if 'X-B3-TraceId' not in headers and 'X-B3-SpanId' not in headers and 'X-B3-ParentSpanId' not in headers and 'X-B3-Sampled' not in headers:
        zattrs = create_attrs_for_span()
        return headers.update({'X-B3-TraceId': zattrs.trace_id,'X-B3-ParentSpanId': zattrs.span_id,'X-B3-SpanId': generate_random_64bit_string(),'X-B3-Sampled': '1' if zattrs.is_sampled else '0'})
    else:
        return headers