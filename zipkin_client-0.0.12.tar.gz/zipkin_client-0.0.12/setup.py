from setuptools import setup

setup(
    name='zipkin_client',
    version='0.0.12',
    description='Client Zipkin to tranfer service data to Zipkin Server',
    license='MIT',
    packages=['zipkin_client'],
    install_requires=[
        'py-zipkin',
        'requests',
    ],
    author='Nopadol Sooktieb',
    author_email='nopadol@openlandscape.cloud',
    include_package_data=True,
)